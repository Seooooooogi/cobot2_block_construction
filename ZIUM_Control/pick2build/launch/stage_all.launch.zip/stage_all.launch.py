import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Stage 1: 데이터 수집 및 코디네이터
        Node(
            package='pick2pack', 
            executable='stage_1_t',
            name='coordinator_node_0',
            output='screen'
        ),
        
        # Stage 2: 휴대폰 본체 P2P 작업
        Node(
            package='pick2pack',
            executable='stage_2_t',
            name='stage_2',
            namespace='dsr01',
            output='screen'
        ),
        
        # Stage 3: 비즈 작업 (Glue, Scooping)
        Node(
            package='pick2pack',
            executable='stage_3_t',
            name='stage_3',
            namespace='dsr01',
            output='screen'
        ),
        
        # Stage 4: 액세서리 작업 (리스트 기반)
        Node(
            package='pick2pack',
            executable='stage_4_t',
            name='stage_4',
            namespace='dsr01',
            output='screen'
        ),
        
        # Stage 5: 박스 밀봉 작업
        Node(
            package='pick2pack',
            executable='stage_5_t',
            name='stage_5',
            namespace='dsr01',
            output='screen'
        )
    ])